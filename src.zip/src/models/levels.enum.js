export const LEVELS = {
    NORMAL: 'Normal',
    URGENT: 'Urgent',
    BLOCKING: 'Blocking',
    PENDING: 'Pending'
}